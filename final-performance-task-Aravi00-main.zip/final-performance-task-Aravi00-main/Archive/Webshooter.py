import pygame as py
import numpy as np
#setup
py.init()
clock = py.time.Clock()

    